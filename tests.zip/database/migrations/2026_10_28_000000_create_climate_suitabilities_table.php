<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('climate_suitabilities', function (Blueprint $table) {
            $table->id();
            $table->string('district', 80);
            $table->string('period', 7);
            $table->decimal('probability', 5, 2);
            $table->timestamps();
            $table->unique(['district', 'period']);
            $table->index('period');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('climate_suitabilities');
    }
};
